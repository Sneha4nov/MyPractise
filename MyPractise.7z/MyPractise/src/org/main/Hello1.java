package org.main;

public class Hello1 {
	void show(String str) {
		System.out.println("Show method started");
		
		try {
			System.out.println("Try block started ");
			int a = Integer.parseInt(str);
			int b = 10/a;
			System.out.println("try block completed "+b);
			
			System.exit(0); // this statement don't let finally block print
		}
		catch(ArithmeticException e) {
			System.out.println("catch block");
		}
		finally {
			System.out.println("finally block");
		}
	}
}