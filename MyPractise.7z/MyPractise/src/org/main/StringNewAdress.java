package org.main;

public class StringNewAdress {
public static void main(String[] args) {
	String diffVariable = "Inside String Constant Pool, Same Value With Same Adress Sneha";
	String diffVariable1 = "Inside String Constant Pool, Same Value With Same Adress Sneha";
	
	String str1 = new String("OutSide Pool , Same Value With Diffrent Adress Sneha");
	String str2 = new String("OutSide Pool , Same Value With Diffrent Adress Sneha");
	String str3 = str2.intern(); // F bcoz both r new String
	
	System.out.println(diffVariable1 == diffVariable);
	System.out.println(str1==str2);
	
	System.out.println("Comparing str1 and str3 with intern making str2"+str1==str3);
	
	String okay = "ok";   // inside String pool
	String ok1 = new String("ok");
	String ok2 = new String("ok"); // with new outside pool
	System.out.println(ok1==ok2);
	 ok1 = ok2.intern();   // with intern method
	 System.out.println(ok1==okay); // T both equal 
}
}
