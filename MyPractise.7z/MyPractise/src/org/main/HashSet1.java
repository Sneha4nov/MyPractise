package org.main;

import java.util.HashSet;

public class HashSet1 {
public static void main(String[] args) {
	HashSet<String> set = new HashSet<String>();
	set.add("Sneha");
	set.add("Sneha");
	set.add("Satya");
	set.add("FB");
	set.add("Ea"); // FB ,Ea having same HashCode
	set.add("Neelaveni");
	set.add("Pallavi");
	
	System.out.println(set);
	
}
}
