package org.main.exceptionhandling.aarayindexoutbound;

import java.util.Scanner;

public class ArrayIndexOutOfBoundsExceptionJD {
public static void main(String[] args) {
	
	Scanner sc = new Scanner(System.in);
	System.out.println("Enter the size of array : ");
	int size = sc.nextInt();
	int[] intaaray = new int[size];
	for(int i =0; i<size;i++) {
		System.out.println("enter value at index no "+i+":");
		intaaray[i] = sc.nextInt();
	}
	System.out.println("Enter the index no for any value");
	int index = sc.nextInt();
	System.out.println("value at index no "+ index +" is :"+intaaray[index]);
}
}