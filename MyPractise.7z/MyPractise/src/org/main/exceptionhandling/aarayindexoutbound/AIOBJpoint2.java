package org.main.exceptionhandling.aarayindexoutbound;

import java.util.HashMap;
import java.util.Iterator;

public class AIOBJpoint2 {
public static void main(String[] args) {
	HashMap<Integer, Integer> map = new HashMap<Integer, Integer>();
	map.put(11, 12);
	map.put(12, 22);
	map.put(13, 32);
	map.put(14, 42);
	
	 final Iterator<Integer> it = map.keySet().iterator();
	
	for(int i = 0; it.hasNext();i++) {
		
		System.out.println(it.next());
	}
}
}
