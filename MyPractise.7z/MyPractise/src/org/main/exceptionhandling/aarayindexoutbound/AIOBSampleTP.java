package org.main.exceptionhandling.aarayindexoutbound;

import java.util.Arrays;
import java.util.Scanner;

public class AIOBSampleTP {
public static void main(String[] args) {
	int[] myArray = {11,12,13,14,15}; 
	System.out.println("array of Integers");
	System.out.println(Arrays.toString(myArray));
	
	Scanner sc = new Scanner(System.in);
	System.out.println("Enter the index no for which element u want :");
	try {
	int element = sc.nextInt();
	System.out.println("the value at index no :"+element+" is :"+myArray[element]);
	}catch(ArrayIndexOutOfBoundsException a) {
		System.out.println("enter a correct index no");
	}
}

}
