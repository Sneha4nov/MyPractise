package org.main.exceptionhandling.aarayindexoutbound;

public class AIOBJpoint {
public static void main(String[] args) {
	String[] arr = {"Dhoni","Rohit","Virat","Kohli"};
	
	//for(int i = 0;i<=arr.length-1;i++) {
	
	for(int i = 0;i<=arr.length;i++) {
		
		System.out.println(arr[i]);
	}
}
}
