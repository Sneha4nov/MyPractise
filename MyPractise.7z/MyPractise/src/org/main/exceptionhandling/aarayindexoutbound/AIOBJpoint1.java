package org.main.exceptionhandling.aarayindexoutbound;

import java.util.ArrayList;

public class AIOBJpoint1 {
public static void main(String[] args) {
	ArrayList<String> list = new ArrayList<String>();
	
	list.add("Dhoni");
	list.add("Rohit");
	list.add("Virat");
	list.add("Kohli");
	
	for(String val : list) {  // for : each() to ignore ArrayIndexOutOfBoundsException
		System.out.println(val);
		
	}
}
}
