package org.main.exceptionhandling.nullpointer;

public class SynchronizedNullObject {
	 //public static String mutex = "Stringobj";
	
	//public static String mutex = null;
	//Object mutex = null;
public static void main(String[] args) {

	//if (mutex==null) mutex=" "; //preventive coding from null pointer
	Object mutex = null;
	synchronized (mutex) {
		System.out.println(String.valueOf(mutex));
		System.out.println("synchronized block");
	}
}
}
