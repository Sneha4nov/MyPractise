package org.main.exceptionhandling.nullpointer;

public class WhenNullIsThrown {
	public static void main(String[] args) throws Exception {

		throw null;
		// throw new Exception();
		//?? how to resolve
	}

}