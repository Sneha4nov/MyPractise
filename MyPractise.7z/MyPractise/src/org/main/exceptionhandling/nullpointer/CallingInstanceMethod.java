package org.main.exceptionhandling.nullpointer;

public class CallingInstanceMethod {
public static void main(String[] args) {
	
	CallingInstanceMethod c = m1();
	c.m2("Hi");
	}

	private static CallingInstanceMethod m1() {
		return null;
	}
	
	public void m2(String s) {  // instance method call with null refrence obj throw null pointer exception
		if(s.equals("Test")) {
			System.out.println("Test");
		System.out.println(s.toLowerCase());
	}}
}
////////////////////////////////

//CallingInstanceMethod c = m1();
//c.m2("Hi");
//}
//
//private static CallingInstanceMethod m1() {
//	return null;
//}
//
//public static void m2(String s) {      // Static method works with null refrence obj
//	System.out.println(s.toLowerCase());
//}
//}
