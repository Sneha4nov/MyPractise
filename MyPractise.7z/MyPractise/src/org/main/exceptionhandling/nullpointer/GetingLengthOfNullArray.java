package org.main.exceptionhandling.nullpointer;

public class GetingLengthOfNullArray {
	public static void main(String[] args) {
		int[] a = null;
	//	int[] a = {1,2,3};
		int leng = a.length; //when getting length of null array
		int b = a[2]; //when accessing/modifying index value of with null array
		
		
	}
	
	public int getArrayLength(Object[] a) {
		if(a == null) throw new IllegalArgumentException("Array is null");
		return a.length;
	}
}
