package org.main.exceptionhandling.nullpointer;

public class NullPassedInMethodArguement {
public static void main(String[] args) {
	
	// m1("Hi");
	m1(null);
}

public static  void m1(String s) {
	System.out.println(s.toLowerCase());
}
}
