package org.main.exceptionhandling.nullpointer;

public class AccessModifyingFieldOfNullObject {
	
	// public static int x = 10;
	
	public int x = 10; // Instance Variable with null refrence throws nullpointer exception
	
public static void main(String[] args) {
	
	
	//......................................
	AccessModifyingFieldOfNullObject refobj = new AccessModifyingFieldOfNullObject();
	int i = refobj.x;
	System.out.println(i);
	//................................................................................
	
	AccessModifyingFieldOfNullObject a = m1();
	int j = a.x;
	
	System.out.println(j);

	

	}

private static  AccessModifyingFieldOfNullObject m1() {
	return null;
}

}
