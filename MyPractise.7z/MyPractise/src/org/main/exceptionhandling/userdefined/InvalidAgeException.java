package org.main.exceptionhandling.userdefined;

public class InvalidAgeException extends Exception {

	 InvalidAgeException(String s) {
		super(s);
	}
}
