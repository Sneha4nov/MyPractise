package org.main.exceptionhandling;

public class MainException {
public static void main(String[] args) throws MyException {
	int i = 5;
	
//	if(i<10) {
//	throw new MyException(".....error msg from MyException class.....");
//}
	
	try {
		if(i<10) {
			throw new MyException(".....error msg from MyException class.....");
		}
	}
	catch (MyException e) {
		System.out.println(e);
	}
}
}
