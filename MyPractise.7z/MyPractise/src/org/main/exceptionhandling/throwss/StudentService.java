package org.main.exceptionhandling.throwss;

import java.io.IOException;

public class StudentService {
String getNameBySid(String sid)throws StudentNotFoundException,IOException {
	if(sid==null || sid.isEmpty()|| !sid.equals("101")) {
		throw new StudentNotFoundException(sid);
	}
	else {
		return "Snehaa";
	}
}
}
