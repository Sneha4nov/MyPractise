package org.main.exceptionhandling.throwss;

public class StudentNotFoundException extends RuntimeException {

	public StudentNotFoundException(String sid) {
		super(sid);
	}

}
