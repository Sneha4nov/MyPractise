package org.main.exceptionhandling.throwss;

public class MainStu {
public static void main(String[] args)
{
	System.out.println("Main Started");

	
	try {
	StudentService stuservice = new StudentService();
	stuservice.getNameBySid(null);
	
//...	String sid = null;
//...	throw new StudentNotFoundException(sid);
	
	}
	catch(Exception e) {
	System.out.println(e);
	 e.printStackTrace();
		System.out.println("Catch block");
	}
	
	
	
}
}
