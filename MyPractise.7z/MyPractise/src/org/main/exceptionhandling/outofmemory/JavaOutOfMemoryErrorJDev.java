package org.main.exceptionhandling.outofmemory;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class JavaOutOfMemoryErrorJDev {
public static void main(String[] args) {
	List<Integer> list = new ArrayList<Integer>();
	Random random = new Random();
	while(true) {
		list.add(random.nextInt());
	}
}
}
