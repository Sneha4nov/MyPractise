package org.main.exceptionhandling.outofmemory;

class Student {
	long aa[] = new long[215833];
}