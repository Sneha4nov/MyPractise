package org.main.exceptionhandling.outofmemory;

public class OutOfMemoryMain {
	public static void main(String[] args) {
		Student stu[] = new Student[500];
		try {
			for (int i = 0; i < stu.length; i++) {

				stu[i] = new Student();

				System.out.println((i + 1) + "Object Created");
			}
		} 
		catch (Exception e) {
			System.out.println("\n Error catched " + e);
		}
		System.out.println("\n After Handling ");
		Student st = new Student();
	}
}

