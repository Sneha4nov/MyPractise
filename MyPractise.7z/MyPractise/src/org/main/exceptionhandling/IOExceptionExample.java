package org.main.exceptionhandling;

import java.io.FileInputStream;
import java.io.FileNotFoundException;

public class IOExceptionExample {
public static void main(String[] args) {
	IOExceptionExample ioex = new IOExceptionExample();
	ioex.checkforfile();
}
	public void checkforfile() {
		try {
			FileInputStream file1 = new FileInputStream("input.txt");
			System.out.println(" inside try with file_input_stream");
		}
		catch(FileNotFoundException filenotfound) {
			System.out.println(filenotfound);
			filenotfound.printStackTrace();
		}
		
	}
}
