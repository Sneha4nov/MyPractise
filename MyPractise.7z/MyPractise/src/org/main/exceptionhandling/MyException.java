package org.main.exceptionhandling;

public class MyException extends Exception {

	public MyException(String msg) {
		super(msg);
	}
}
