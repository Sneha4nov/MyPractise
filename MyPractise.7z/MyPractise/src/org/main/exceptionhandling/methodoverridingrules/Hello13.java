package org.main.exceptionhandling.methodoverridingrules;

import java.io.IOException;

public class Hello13 {

	void show() throws IOException, ClassNotFoundException {
	
//ClassNotFoundException is super E to IOException
		//Subclass cannot throw superE , which superE to SuperC_method_E
		System.out.println("Hello13 show() method");
	}
}
