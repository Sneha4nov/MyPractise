package org.main.exceptionhandling.methodoverridingrules;

public class Hello12 extends Hello11 {

	void show() throws Exception {
		
		// when SuperC is throwing Checked Exception
		// then SubC cannot throw Super_Class_Exception (super from checked E)
		System.out.println("Hello12 show() method");
	}
}