package org.main.exceptionhandling.methodoverridingrules;

public class Hello6 extends Hello5 {
void show() {
	System.out.println("Hello6 show() method");
}
void display() throws NullPointerException   {
	System.out.println("Hello6 display() method");
	
}
}
