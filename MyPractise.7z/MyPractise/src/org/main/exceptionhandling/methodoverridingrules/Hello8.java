package org.main.exceptionhandling.methodoverridingrules;

public class Hello8 extends Hello7 {

	void show() throws NullPointerException {
		// when SuperC is throwing Checked Exception
		// then SubC can throw UnChecked Exception
		System.out.println("Hello8 show() method");
	}
}
