package org.main.exceptionhandling.methodoverridingrules;

public class Hello17 {

	void show() throws ArrayIndexOutOfBoundsException {
		
	//for unchecked any spuer sub E of each other anywhere e can give
		
		System.out.println("Hello17 show() method");
	}
}
