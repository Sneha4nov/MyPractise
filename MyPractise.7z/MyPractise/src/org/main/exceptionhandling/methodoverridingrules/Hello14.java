package org.main.exceptionhandling.methodoverridingrules;

public class Hello14 extends Hello13 {

	void show() throws ClassNotFoundException {
		
		//ClassNotFoundException is super E to IOException
				//Subclass cannot throw superE , which superE to SuperC_method_E
		System.out.println("Hello14 show() method");
	}
}