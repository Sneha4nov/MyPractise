package org.main.exceptionhandling.methodoverridingrules;

public class Hello3 {
	
//	void show()  {
//		 if having ClassNotFoundException in Subclass then need to create in Super or remove from sub
//		System.out.println("Hello3 show() method");
//	}
	
void show() throws ClassNotFoundException {
	System.out.println("Hello3 show() method");
}

}
