package org.main.exceptionhandling.methodoverridingrules;

public class Hello4 extends Hello3 {
	
	// if having ClassNotFoundException in Subclass then need to create in Super or remove from sub
void show() throws ClassNotFoundException {
	System.out.println("Hello4 show() method");
}

}
