package org.main.exceptionhandling.methodoverridingrules;

import java.io.IOException;

public class MainHello {
public static void main(String[] args) throws Exception  {
	Hello1 h = new Hello1();
	h.display();
	h.show();
	
	Hello1 h1 = new Hello2(); //dynamic dispatch
	h1.display();
	h1.show();
	
	Hello3 h3 = new Hello3();
	h3.show();
	
	Hello4 h4 = new Hello4();
	h4.show();
	
	Hello5 h5 = new Hello5();
	h5.display();
	h5.show();
	
	Hello5 h6 = new Hello6(); //dynamic dispatch
	h6.display();
	h6.show();
	
	Hello7 h7 = new Hello7();
	h7.show();
	// when SuperC h7 is throwing Checked Exception
	// then SubC h8 can throw UnChecked Exception 
	Hello8 h8 = new Hello8();
	h8.show();
	
	Hello9 h9 = new Hello9();
	h9.show();
	// SuperE IOException SubE FileNotFoundException
	
			// when SuperC is throwing Checked Exception
			// then SubC can throw Sub_Checked_Exception of SuperClass's Checked_Exception
	
	Hello9 h10 = new Hello10(); //dynamic dispatch
	h10.show();
	
	
	Hello11 h11 = new Hello11();
	h11.show();
	
	// when SuperC is throwing Checked Exception
			// then SubC cannot throw Super_Class_Exception (super from checked E)
	
	Hello11 h12 = new Hello12(); //dynamic dispatch
	h12.show();
	
	
	Hello13 h13 = new Hello13();
	h13.show();
	
	//ClassNotFoundException is super E to IOException
			//Subclass cannot throw superE , which superE to SuperC_method_E
	
	Hello13 h14 = new Hello14(); //dynamic dispatch
	h14.show();
	
	Hello15 h15 = new Hello15();
	h15.show();
	
	//for unchecked any spuer sub E of each other anywhere e can give
	
	Hello15 h16 = new Hello16(); //dynamic dispatch
	h16.show();
	////////////////////////////
	
	Hello17 h17 = new Hello17();
	h17.show();
	
	//for unchecked any spuer sub E of each other anywhere e can give
	
	Hello17 h18 = new Hello18(); //dynamic dispatch
	h18.show();
	///////////////////////////
	
	Hello19 h19 = new Hello19();
	h19.show();
	
	//RuntimeE_in _SuperC  with Exception_in_SubC can have error
	
	Hello19 h20 = new Hello20(); //dynamic dispatch
	h20.show();
	///////////////////////////
	
	Hello21 h21 = new Hello21();
	h21.show();
	
	// When ArrayIndexOutOfBoundsException_(Runtime) in SUPER_C & ClassNotFoundException_(checked) in SUB_C 
	// WILL NOT WORK it cannot throw any checked in sub 
	
	Hello21 h22 = new Hello22(); //dynamic dispatch
	h22.show();
}
}
