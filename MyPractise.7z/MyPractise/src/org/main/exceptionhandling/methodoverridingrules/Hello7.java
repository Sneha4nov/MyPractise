package org.main.exceptionhandling.methodoverridingrules;

import java.io.IOException;

public class Hello7 {

	void show() throws IOException {
		// when SuperC is throwing Checked Exception
		// then SubC can throw UnChecked Exception
		System.out.println("Hello7 show() method");
	}
}
