package org.main.exceptionhandling.methodoverridingrules;

public class Hello20 extends Hello19 {

	void show() throws Exception   {
		
		//RuntimeE_in _SuperC  with Exception_in_SubC can have error 
		
		System.out.println("Hello20 show() method");
	}
}