package org.main.exceptionhandling.methodoverridingrules;

import java.io.IOException;

public class Hello9 {

	void show() throws IOException {
		// SuperE IOException SubE FileNotFoundException
		
		// when SuperC is throwing Checked Exception
		// then SubC can throw Sub_Checked_Exception of SuperClass's Checked_Exception
		System.out.println("Hello9 show() method");
	}
}
