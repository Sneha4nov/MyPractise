package org.main.exceptionhandling.methodoverridingrules;

import java.io.IOException;

public class Hello11 {

	void show() throws IOException, Exception {
	
		// when SuperC is throwing Checked Exception
		// then SubC cannot throw Super_Class_Exception (super from checked E)
		System.out.println("Hello11 show() method");
	}
}
