package org.main.exceptionhandling.methodoverridingrules;

public class Hello5 {
void show() {
	System.out.println("Hello5 show() method");
}
void display()  {
	System.out.println("Hello5 display() method");
}
}
