package org.main.exceptionhandling.methodoverridingrules;

import java.io.FileNotFoundException;

public class Hello10 extends Hello9 {

	void show() throws FileNotFoundException {
		
		// SuperE IOException SubE FileNotFoundException
		
		// when SuperC is throwing Checked Exception
		// then SubC can throw Sub_Checked_Exception of SuperClass's Checked_Exception
		System.out.println("Hello10 show() method");
	}
}
