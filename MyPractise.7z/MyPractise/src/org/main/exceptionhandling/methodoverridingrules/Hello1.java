package org.main.exceptionhandling.methodoverridingrules;

import java.io.IOException;

public class Hello1 {
void show() {
	System.out.println("Hello1 show() method");
}
void display() throws IOException {
	System.out.println("Hello1 display() method");
}
}
