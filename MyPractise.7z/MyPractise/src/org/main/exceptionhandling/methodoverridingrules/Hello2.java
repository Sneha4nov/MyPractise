package org.main.exceptionhandling.methodoverridingrules;

import java.io.IOException;

public class Hello2 extends Hello1 {
void show() {
	System.out.println("Hello2 show() method");
}
void display() throws IOException   {
	System.out.println("Hello2 display() method");
	
	
}
}
