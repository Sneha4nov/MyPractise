package org.main.exceptionhandling.methodoverridingrules;

public class Hello18 extends Hello17 {

	void show() throws RuntimeException   {
		
		//for unchecked any spuer sub E of each other anywhere e can give
		
		System.out.println("Hello18 show() method");
	}
}