package org.main.exceptionhandling.methodoverridingrules;

public class Hello21 {

	void show() throws ArrayIndexOutOfBoundsException, ClassNotFoundException {
		
		// When ArrayIndexOutOfBoundsException_(Runtime) in SUPER_C & ClassNotFoundException_(checked) in SUB_C 
		// WILL NOT WORK it cannot throw any checked in sub
		
		System.out.println("Hello21 show() method");
	}
}
