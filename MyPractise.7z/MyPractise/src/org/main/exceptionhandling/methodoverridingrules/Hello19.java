package org.main.exceptionhandling.methodoverridingrules;

public class Hello19 {

	void show() throws ArrayIndexOutOfBoundsException, Exception {
		
		//RuntimeE_in _SuperC  with Exception_in_SubC can have error 
		
		System.out.println("Hello19 show() method");
	}
}
