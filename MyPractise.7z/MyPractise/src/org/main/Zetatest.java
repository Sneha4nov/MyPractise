package org.main;
import java.util.Scanner;
public class Zetatest {

public static void main(String[] args) {
	ZetaBMI zetaBMI = new ZetaBMI();
	zetaBMI.returnheight(0);
	zetaBMI.returnweight(10);
	zetaBMI.calculateBMI(10, 10);

}


}
