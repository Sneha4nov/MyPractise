package org.main;

public class ObjectWrapperInt {
	public static void main(String[] args) {
		
		A a = new A();
		a.m1(10, 20);
	}

}

class A {

	public Object m1(Object a, Object b) {
		System.out.println("Obj");
		return b;
	}

	public  Integer m1(Integer a,Integer b){
		System.out.println("Wrap");
		return b;
	}

	public int m1(int a, int b) {
		System.out.println("int");
		return b;

  
	}

}