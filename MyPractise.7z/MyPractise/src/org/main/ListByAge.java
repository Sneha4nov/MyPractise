package org.main;

import java.util.List;

public class ListByAge  {
public static void main(String[] args) {
//	List list = new Arraylist();
	
	
}
}
