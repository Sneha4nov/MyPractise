package org.main;

public class TryCatchFinally {
public static void main(String[] args) {
	System.out.println("Main Started..");
	new Hello1().show("3");
	
//	Hello1 h = new Hello1();
//	h.show("3");
}
}
