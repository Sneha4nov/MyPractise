package org.main.abstractt;

public class Hai extends Hello {

	public Hai(int b) {
		super(b);
		
	}

}
