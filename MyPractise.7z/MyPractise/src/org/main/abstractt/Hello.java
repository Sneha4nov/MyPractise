package org.main.abstractt;

abstract class Hello {
int b;

public Hello(int b) {
	super();
	this.b = b;
}

{
	System.out.println("block in abstract class");
}
void show1() {
	System.out.println("show in Hello class");
}
}
