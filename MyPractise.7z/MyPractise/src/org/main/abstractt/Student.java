package org.main.abstractt;

abstract class Student extends Person {
	void sleeping() {

		System.out.println("Student -> Sleeping");
	}
}
