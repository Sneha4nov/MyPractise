package org.main.abstractt;

public class AbstractMain {
public static void main(String[] args) {
	Person p = new CurrentStudent();
	
	System.out.println(Person.a); //static variable from abstract class
	
	Person.show(); //static method from abstract class
	p.sleeping();
	p.walking();
	System.out.println("..................................");
	Hello hai = new Hai(10);
		hai.show1();
	
}
}
