package org.main.abstractt;

class CurrentStudent extends Student {

	@Override
	void walking() {
		System.out.println("student -> walking");

	}

}
