package org.main.abstractt;

abstract class Person {
	abstract void sleeping(); 
	abstract void walking(); 
	
	static int a = 1234;
	static void show() {  //concreate method in abstract
		System.out.println("Show Method");
	}

}
