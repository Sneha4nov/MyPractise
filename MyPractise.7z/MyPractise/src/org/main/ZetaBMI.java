package org.main;

import java.util.Scanner;

public class ZetaBMI {
	public float returnweight(float str) {

		Scanner sc = new Scanner(System.in);
		System.out.print("Input weight in kilogram: ");
		double weight = sc.nextDouble();
		str = (float) weight;
		return str;

	}

	public float returnheight(float str) {
		Scanner sc = new Scanner(System.in);
		System.out.print("\nInput height in meters: ");
		double height = sc.nextDouble();
		str = (float) height;
		return str;

	}

	public float calculateBMI(float height, float weight) {
		
			double BMI = weight / (height * weight);
			System.out.println(weight);
			System.out.println(height);
				System.out.print("\nThe Body Mass Index (BMI) is " + BMI + " kg/m2");

				return (float) BMI;

	}
	
	
	public void checkstatus(float bmi) {
	
		
		
	}
	

}
