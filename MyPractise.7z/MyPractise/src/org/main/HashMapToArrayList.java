package org.main;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;



public class HashMapToArrayList {
public static void main(String[] args) {
	HashMap<String, String> map = new HashMap<String, String>();
	
	map.put("Sonam", "Bajwa");
	map.put("Neeru", "Bajwa");
	map.put("Diljit", "Dosanjh");
	map.put("Jassi", "Gill");
	
	Set<String> keySet = map.keySet();
	ArrayList<String> listkey = new ArrayList<String>(keySet);
	System.out.println("............LIST BY KEYS.........");
	for(String key : listkey) {
		System.out.println(key);
	}
	
	Collection<String> values = map.values();
	ArrayList<String> listValues = new ArrayList<String>(values);
	System.out.println("..........LIST BY VALUES .........");
	for(String val : listValues) {
		System.out.println(val);
	}
	
	Set<Entry<String,String>> entrySet = map.entrySet();
	ArrayList<Entry<String, String>> mapToArray = new ArrayList<Map.Entry<String,String>>(entrySet);
	System.out.println(".......ArrayList of HashMap....... ");
	for(Entry<String, String> arr : mapToArray) {
		System.out.println(arr.getKey()+" : "+arr.getValue());
		
	}
}
}
