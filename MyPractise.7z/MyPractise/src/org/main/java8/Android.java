package org.main.java8;

public class Android implements Phone {

	public void call() {
		System.out.println(" Calling ");

	}

}