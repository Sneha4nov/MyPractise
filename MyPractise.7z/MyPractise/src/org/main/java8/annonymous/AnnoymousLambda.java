package org.main.java8.annonymous;

interface A {
	void show();
}

public class AnnoymousLambda {
public static void main(String[] args) {
	A obj;
//	obj = new A()
//			{
//		public void show() {
//			System.out.println("show inside Annonymous class");
//		}
//			};
//	obj.show();
	//.....................................
	
	 obj = () -> System.out.println("show inside Annonymous class");
	
	//.....................................
	obj = () -> { 
		System.out.println("show inside Annonymous class") ;
		};
	
	obj.show();
}
}
