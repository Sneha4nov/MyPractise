package org.main.java8.annonymous;

	public class B implements A {
		
//		public void show() {
//			System.out.println("class b show");		
//		}
	}
