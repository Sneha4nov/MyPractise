package org.main.java8.functionbinaryop;

import java.util.Arrays;
import java.util.List;
import java.util.function.BinaryOperator;
import java.util.function.Function;
import java.util.stream.Stream;

public class MapReduce2 {
public static void main(String[] args) {
	List<Integer> values = Arrays.asList(11,22,33,44,55,66);
	//int result = 0;
	
	
//	System.out.println(values.stream().map(i -> i*2).reduce(0,(c,e)->c+e));
	
	
	Stream s = values.stream();
	Stream s1 = s.map(new Function<Integer, Integer>() { // ANNONYMOUS_ CLASS
		
		
		public Integer apply(Integer i) {
			
			return i*2;
		}
	});
	
	Integer result1 = (Integer)s1.reduce(0,new BinaryOperator<Integer>() {  // ANNONYMOUS_ CLASS

		public Integer apply(Integer i, Integer j) {
			
			return i+j;
		}
	});
	
	System.out.println(result1);
	
			}
}


