package org.main.java8.functionbinaryop;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

public class MapReduce3 {
public static void main(String[] args) {
	List<Integer> values = Arrays.asList(11,22,33,44,55,66);
	//int result = 0;
	
	
//	System.out.println(values.stream().map(i -> i*2).reduce(0,(c,e)->c+e));
	
	
	Stream<Integer> s = values.stream();
	Stream<Integer> s1 = s.map( i ->  i*2);
		
	
	
	Integer result1 = (Integer)s1.reduce(0,( i, j) ->  i+j);
		
	
	
	System.out.println(result1);
	
			}
}


