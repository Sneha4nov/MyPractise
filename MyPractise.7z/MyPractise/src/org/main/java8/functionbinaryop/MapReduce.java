package org.main.java8.functionbinaryop;

import java.util.Arrays;
import java.util.List;
import java.util.function.BinaryOperator;
import java.util.function.Function;
import java.util.stream.Stream;

public class MapReduce {
public static void main(String[] args) {
	List<Integer> values = Arrays.asList(11,22,33,44,55,66);
	int result = 0;
	
	
//	for(int i : values) {
//		result = result + i*2;
//	}
//	System.out.println(result);
	
	System.out.println(values.stream().map(i -> i*2).reduce(0,(c,e)->c+e));
	
	Function<Integer, Integer> f = new Function<Integer, Integer>() {
		
		
		public Integer apply(Integer i) {
			
			return i*2;
		}
	};
	
	BinaryOperator<Integer> b = new BinaryOperator<Integer>() {

		public Integer apply(Integer i, Integer j) {
			
			return i+j;
		}
	};
	
	Stream s = values.stream();
	Stream s1 = s.map(f);
	
	Integer result1 = (Integer)s1.reduce(0,b);
	
	System.out.println(result1);
	
			}
}


