package org.main.java8.consumer;

import java.util.Arrays;
import java.util.List;
import java.util.function.Consumer;

public class MainConsumer {
public static void main(String[] args) {
	List<Integer> values = Arrays.asList(4,5,6,7,8);
	
	//...............................................
	
//	Consumer<Integer> c = new Consumer<Integer>() {
//		
//		public void accept(Integer i) {			
//			
//			System.out.println(i);
//		}
//		
//	};
	
	//...............................................
	
//	Consumer<Integer> c = (Integer i)-> {			
//			// Annonymous class
//			System.out.println(i);
//		}
//		
//	;
	

	//............................................
	
//	Consumer<Integer> c =  i-> System.out.println(i);
	
//....................................................
	
	//Consumer<Integer> c =  i-> System.out.println(i);
	
// values.forEach(c); past this line instead c
	
	values.forEach(i-> System.out.println(i));
	
//values.forEach(i -> System.out.println(i));
}
}




