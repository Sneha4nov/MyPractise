package org.main.java8.consumer;

import java.util.function.Consumer;

public class ConsImpl implements Consumer<Integer> {

//		public void accept(Integer i) {
//			
//			System.out.println(i);
//		}
		
	}