package org.main.java8;

public class ForEachArrayElements {
public static void main(String[] args) {
	int arr[] = {11,22,33,44,55,66};
	int total =0;
	for(int i : arr) {
		System.out.println(i);
	}
	
	for(int j : arr) {
		total = total + j;
		
	}
	System.out.println("Total : " + total);
}
}
