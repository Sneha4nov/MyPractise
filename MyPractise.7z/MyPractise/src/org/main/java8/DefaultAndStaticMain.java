package org.main.java8;

interface Phone {
	void call();
	default void message() {
		System.out.println(" sent ");
	}
	
	static  String whatsapp() {
		System.out.println(" Whatsapp Static method ");
		return null;
			
	}
}

public class DefaultAndStaticMain {
public static void main(String[] args) {
	Phone p = new Android();
	p.call();
	p.message();
}
}
