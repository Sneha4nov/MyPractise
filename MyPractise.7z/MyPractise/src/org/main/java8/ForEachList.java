package org.main.java8;

import java.util.ArrayList;

public class ForEachList {
public static void main(String[] args) {
	ArrayList<String> list = new ArrayList<String>();
	
	list.add("Sneha");
	list.add("Satya");
	list.add("Neelaveni");
	list.add("Pallavi");
	
	for(String s : list) {
		System.out.println(s);
	}
}
}
