package org.main;

import java.util.LinkedList;

public class LinkedListImpl {
public static void main(String[] args) {
	
	LinkedList<String> list = new LinkedList<String>();
	list.add("Sneha");
	list.add("Pallavi");
	list.add("Satya");
   list.add("Neelaveni");
	list.add("Narsimha");
	
	for(String s : list) {
		System.out.println("inside for");
		System.out.println(s);	
	}
	
	System.out.println(list);
}
}
