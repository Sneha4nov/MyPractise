package org.main;

public class FinalReverseWithoutUsingStringMethod {
public static void main(String[] args) {
//	String str = "Automation";
//	StringBuilder str2 = new StringBuilder();
//	str2.append(str);
//	str2 = str2.reverse();
//	System.out.println(str2);
	
String expr = "Java Code";
String res[] = expr.split("a",2);

for(int i=0;i<res.length;i++) {
	String st = res[i];
	System.out.println(i+"\t"+st);
}

}
}
