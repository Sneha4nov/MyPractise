package org.main;

public class SwapTwoNoWithoutThirdVariable {
public static void main(String[] args) {
	int x=10,y=30;
	System.out.println("Before Swap"+x+" "+y);
	x= x+y;
	y= x-y;
	x=x-y;
	System.out.println("After"+x+" "+y);
}
}
