package org.main.list;

public class Employee {
private int id;
private String FirstName;
private String LAstName;
private int age;



public Employee(int id, String firstName, String lAstName, int age) {
	super();
	this.id = id;
	this.FirstName = firstName;
	this.LAstName = lAstName;
	this.age = age;
}
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getFirstName() {
	return FirstName;
}
public void setFirstName(String firstName) {
	FirstName = firstName;
}
public String getLAstName() {
	return LAstName;
}
public void setLAstName(String lAstName) {
	LAstName = lAstName;
}
public int getAge() {
	return age;
}
public void setAge(int age) {
	this.age = age;
}
@Override
public String toString() {
	return "Employee [id=" + id + ", FirstName=" + FirstName + ", LAstName=" + LAstName + ", age=" + age + "]";
}


}
