package org.main.list;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
// Converting List into MAP
public class ListToMap {
	public static void main(String[] args) {

		List<Employee> list = new ArrayList<Employee>();
		list.add(new Employee(11, "Sneha", "Dani", 22));
		list.add(new Employee(12, "Shiv", "Reddy", 32));
		list.add(new Employee(14, "Neelaveni", "Thakur", 42));
		list.add(new Employee(14, "Soniya", "Sharma", 45));

		Map<Integer, Employee> map = new HashMap<Integer, Employee>();

		for (Employee emp : list) {
			map.put(emp.getId(), emp);
		}
		System.out.println(map);

		List<Map<Integer, Employee>> liMp = new ArrayList<Map<Integer, Employee>>();
		liMp.add(map);
		System.out.println(liMp);

	}
}
