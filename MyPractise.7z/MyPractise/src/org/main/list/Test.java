package org.main.list;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
//sort by age & Name
public class Test {
public static void main(String[] args) {
	Employee e1 = new Employee(1,"Sneha","Dani",24);
	Employee e2 = new Employee(2,"Chandreyee","Datta",21);
	Employee e3 = new Employee(3,"Satya","Rao",65);
	Employee e4 = new Employee(4,"Pallavi","T",22);
	Employee e5 = new Employee(5,"Neelaveni","Thakur",32);
	Employee e6 = new Employee(6,"Diljit","Dosanjh",35);
	List<Employee> employee = new ArrayList<Employee>();
	employee.add(e1);
	employee.add(e2);
	employee.add(e3);
	employee.add(e4);
	employee.add(e5);
	employee.add(e6);
	System.out.println("unsorted "+employee);
	
	
	
	Collections.sort(employee, new SortByAgeList());
	
	System.out.println("Sorted by Age "+employee);
	
	Collections.sort(employee, new SortByNameList());
	System.out.println("Sorted by Name "+employee);
	//.............................................
	System.out.println(".........After using Lambda Sort by age..........");
	employee.sort((Employee emp1, Employee emp2) -> emp1.getAge()-emp2.getAge());
	
	employee.forEach((s)-> System.out.println(s));
	
	//...................................................
	System.out.println(".........After using Lambda Sort by age in REVERSE Order..........");
	
	employee.sort((Employee m1, Employee m2) -> m2.getAge()-m1.getAge());
	
	employee.forEach((rev)-> System.out.println(rev));
}
}
