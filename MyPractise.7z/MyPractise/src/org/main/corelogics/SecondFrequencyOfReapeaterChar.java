package org.main.corelogics;

import java.util.HashMap;

//public class SecondFrequencyOfReapeaterChar {
//	
//
//	public Character secondCommon(String str)
//    {
//        Character ans = null;
//        int first = 0, second = 0;
//        Character firstChar = null,secondChar = null;
//        HashMap<Character,Integer> counter = new HashMap<>();
//        for(char c: str.toCharArray())
//        {
//            if(!counter.containsKey(c))
//            {
//                counter.put(c,1);
//            }
//            else
//            {
//                counter.put(c,counter.get(c) + 1);
//            }
//        }
//        System.out.println(counter);
//       for (char c: counter.keySet())
//       {
//           if(counter.get(c) > first)
//           {
//
//               second = first;
//               secondChar = firstChar;
//               firstChar = c;
//
//               first = counter.get(c);
//           }
//           else
//               if(counter.get(c) > second && counter.get(c) < first)
//           {
//               second = counter.get(c);
//
//               secondChar = c;
//           }
//       }
//        return secondChar;
//    }
//	
//	  public static void main(String[] args) {
//		  SecondFrequencyOfReapeaterChar o = new SecondFrequencyOfReapeaterChar();
//	        System.out.println("Second most repeating char is : "+o.secondCommon("bnnssss"));
//	    }
//	}


//.................................................................................





public class SecondFrequencyOfReapeaterChar {
 
	public Character secondCommon(String str){

Character ans = null;
int first = 0, second = 0;
Character firstChar = null,secondChar = null;

HashMap<Character,Integer> counter = new HashMap<>();

for(char c: str.toCharArray()){

if(!counter.containsKey(c)){
counter.put(c,1);
}
else{
counter.put(c,counter.get(c) + 1);
}}
System.out.println(counter);

for (char c: counter.keySet()){
if(counter.get(c) > first){
second = first;
secondChar = firstChar;

firstChar = c;

first = counter.get(c);
}
else
if(counter.get(c) > second && counter.get(c) < first){

second = counter.get(c);
secondChar = c;
}}
System.out.println("secondChar \n"+secondChar);
int secound=0;
for(char c: str.toCharArray()){
if(secondChar.equals(c)){
secound++;
}
}
System.out.println("secondChar \n"+secondChar);
System.out.println("second count  \n"+second);
return secondChar;
}

public static void main(String[] args) {
SecondFrequencyOfReapeaterChar o = new SecondFrequencyOfReapeaterChar();
System.out.println("Second most repeating char is : "+o.secondCommon("bnnssss"));

}

}



