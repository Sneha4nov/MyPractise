package org.main.corelogics;

import java.util.HashMap;

public class EachCharacterCountInString {
	public static void main(String[] args) {
		characterCount("aaabbc"); 
		
	}
public static int max;

	static void characterCount(String inputString) {
		 char[] ch = inputString.toCharArray();
		HashMap<Character, Integer> eachCharCountMap = new HashMap<Character, Integer>();
		
		char[] charArray = inputString.toCharArray();

		for (char c : charArray) {
			if (eachCharCountMap.containsKey(c)) {
				eachCharCountMap.put(c, eachCharCountMap.get(c) + 1);
			max = eachCharCountMap.get(c);
			} else {
				eachCharCountMap.put(c, 1);
			//min = 1;
			
			}
			
		}
	
		System.out.println(max);
		System.out.println(eachCharCountMap);

	}

}
