package org.main.corelogics;
import java.util.LinkedList;
import java.util.Scanner;

public class MToTheLastElement {
 public static void main(String[] args) {
	        Scanner input = new Scanner(System.in);
	        LinkedList<Integer> linkedList = new LinkedList<>();

	        while (input.hasNext())
	            linkedList.push(input.nextInt());

	        System.out.println("fin");
	    }
	
}