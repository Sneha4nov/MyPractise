package org.main;

public class ReverseString {
public static void main(String[] args) {
	System.out.println("Reverse String Code");
	String str = "Daniel Redicluff";
	char chars[] = str.toCharArray();
	for(int i =chars.length-1; i>=0;i--) {
		System.out.println(chars[i]);
	}
}
}
