package org.main;

public class SwapTwoNumbers {
public static void main(String[] args) {
	int x =10 ,y = 20 ,temp;
	System.out.println("before Swapping"+x+" "+y);
	temp = x;
	x= y;
	y=temp;
	System.out.println("After Swapping"+x+" "+y);
}
}
