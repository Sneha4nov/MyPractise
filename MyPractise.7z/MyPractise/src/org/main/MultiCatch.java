package org.main;

import java.io.IOException;
import java.sql.SQLException;

public class MultiCatch {

	public static void main(String[] args) throws SQLException    {

		try {
			int x = 10;
			int y = x/ 0;
			System.out.println(y);
		}

	//	catch(SQLException  e) {
		catch (ClassCastException|VirtualMachineError|IndexOutOfBoundsException|NegativeArraySizeException|NumberFormatException | ArithmeticException  | NullPointerException e) {
		//	catch(Exception e) {
			System.out.println("provide one non zero value");
		}
		finally {
			System.out.println("finally");
		}
	}
}
