package org.main.concurrenthashmap;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class MainClass {
public static void main(String[] args) {
	
	Map<String, Integer> syncmap = new ConcurrentHashMap<String, Integer>();
	
	MapHelper1  mapHelper1 = new MapHelper1(syncmap);
	MapHelper2  mapHelper2 = new MapHelper2(syncmap);
	MapHelper3  mapHelper3 = new MapHelper3(syncmap);
	MapHelper4  mapHelper4 = new MapHelper4(syncmap);
	
	for(Map.Entry<String, Integer> e : syncmap.entrySet()) {
		System.out.println(e.getKey()+" "+e.getValue());
	}
}
}
