package org.main;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Scanner;

public class HashSetClass {
public static void main(String[] args) {
	
	HashSet<String> h = new HashSet<String>();
	h.add("first value");
	h.add("second value");
	h.add("third value");
	h.add("fourth value");
	h.add("five value");
	
	System.out.println(h);
	
	//...........................................
//	 Scanner myObj = new Scanner(System.in);
//	    String userName;
//	    
//	    // Enter username and press Enter
//	    System.out.println("Enter index no to print value"); 
//	    
//	    userName = myObj.nextLine();   
//	       
//	    System.out.println("values is: " + userName);  
//	    
	
}
}
