package org.main;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class HashMapInternalWorking {

private static final Object Shivam = "Shivam";

public static void main(String[] args) {
	Hello h = new Hello();
	h.show();
	Map<String, Integer> map = new HashMap<String, Integer>();
	
	map.put("Austin", 1);
	map.put("Belgium", 2);
	map.put("Canada", 3);
	map.put("Dubai", 4);
	System.out.println(map);
	
}
}
class Hello {
	public void show() {
		System.out.println("Hello");
	}
}